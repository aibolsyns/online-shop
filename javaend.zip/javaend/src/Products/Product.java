package Products;
public abstract class Product//abstract class
{
    protected String name;//fields
    protected double price;
    protected String manufacture;

    public Product(String name, double price, String manufacture) // Constructor
    {
        this.name = name;
        this.price = price;
        this.manufacture = manufacture;
    }
    //getters
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getManufacture() {
        return manufacture;
    }
}
