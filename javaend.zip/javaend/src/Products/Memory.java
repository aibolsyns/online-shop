package Products;

public abstract class Memory extends Product//extending abstract class
{
    protected int capacity;//fields
    protected int speed;

    public Memory(String name, double price, String manufacture, int capacity, int speed) {//constructor
        super(name, price, manufacture);
        this.capacity = capacity;
        this.speed = speed;
    }
    //getters
    public int getCapacity() {
        return capacity;
    }

    public int getSpeed() {
        return speed;
    }
}
