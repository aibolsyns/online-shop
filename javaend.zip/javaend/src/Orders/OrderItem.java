package Orders;
import Products.Product;

public class OrderItem
{
    private final Product product;//fields
    private int amount;
    private double totalPrice;

    public OrderItem(Product product, int amount)//constructor
    {
        this.product = product;
        this.amount = amount;
        totalPrice = product.getPrice() * amount;
    }
    //getters and setters

    public Product getProduct() {
        return product;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
        totalPrice = amount * product.getPrice();//formula to get total price
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public String toString() {
        return "OrderItem{" +
                "product=" + product +
                ", amount=" + amount +
                ", totalPrice=" + totalPrice +
                '}';
    }
}

